
from flask import Flask, request
import requests

app = Flask(__name__)

TOKEN = "7281967575:AAHCXsMmKwiGNNEBvRxCj30LBzfi2TrMnL0"
URL = f"https://api.telegram.org/bot{TOKEN}/sendMessage"

@app.route("/", methods=["POST"])
def webhook():
    data = request.get_json()
    if "message" in data and "text" in data["message"]:
        chat_id = data["message"]["chat"]["id"]
        text = data["message"]["text"].lower()

        if "btc" in text:
            response = "BTC Signal: BUY at support, TP near resistance."
        elif "eth" in text:
            response = "ETH Signal: Watch for breakout before entering."
        elif "xau" in text or "gold" in text:
            response = "GOLD Signal: Consider selling if price breaks below $2300."
        else:
            response = "Send 'btc', 'eth', or 'gold/xau' to get signals."

        requests.post(URL, json={"chat_id": chat_id, "text": response})
    return {"ok": True}
